

<?php
echo heading("Smazat znacku", 1);
$atributy = array(
    'class' => 'form-horizontal'
    );
$hidden = array(
    'idZnacka' => $znacka[0]->idZnacka,
);
echo form_open('Administrace/smazZnacku', $atributy, $hidden);
//tady začíná první řádek

echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Název značky: ','nazevZnacky', $atributy);

echo "<div class='col-sm-6'>";

$atributy = array(
  'class' => 'form-control',
    'id' => 'nazevZnacky',
    'value' => $znacka[0]->nazevZnacky,
    'name' => 'nazevZnacky'
);    
echo form_input($atributy);

$data = array(
    'name' => 'Smazat',
    'type' => 'submit',
    'content' => 'Smazat značku',
    'class' => 'btn btn-danger'
);
echo "<div class='form-group'>";
echo "<div class='col-sm-offset-2 col-sm-4'>";
echo form_button($data);
echo "</div></div>"; 
echo form_close();

echo "<a class=anavratove href=" .base_url('/editace') . ">Zpět k značkám</a>";