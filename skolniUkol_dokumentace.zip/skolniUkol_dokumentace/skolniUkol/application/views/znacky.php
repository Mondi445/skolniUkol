<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">

    <!-- Website CSS style -->
    <link rel="stylesheet" type="text/css" href="assets/css/main.css">

    <!-- Website Font style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">

    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>
</head>

<script>
function myFunction() {
  base_url('Neprihlasen/radit');
}
</script>

<body>
    <div class="container odsazeni">
        <div class="row blog">
            <div class="col-sm-12">
                <div id="blogCarousel" class="carousel slide" data-ride="carousel">
                    <div class="main-login2 main-center2">


                        <!-- Carousel items -->
                            <h1 class="title text-center" >
                                Automobilové značky
                            </h1>

                            <div class="carousel-item active">
                                <div class="row">
                                    <?php
                                    if (!function_exists('generateBreadcrumb')) {

                                        function generateBreadcrumb() {
                                            $ci = &get_instance();
                                            $i = 1;
                                            $uri = $ci->uri->segment($i);
                                            $link = '<div class="pageheader"><div class="breadcrumb-wrapper"><ol class="breadcrumb">';
                                            while ($uri != '') {
                                                $prep_link = '';
                                                for ($j = 1; $j <= $i; $j++) {
                                                    $prep_link .= $ci->uri->segment($j) . '/';
                                                }
                                                if ($ci->uri->segment($i + 1) == '') {
                                                    $link .= '<li class="active"><a href="' . site_url($prep_link) . '">';
                                                    $link .= $ci->uri->segment($i) . '</a></li>';
                                                } else {
                                                    $link .= '<li><a href="' . site_url($prep_link) . '">';
                                                    $link .= $ci->uri->segment($i) . '</a><span class="divider"></span></li>';
                                                }
                                                $i++;
                                                $uri = $ci->uri->segment($i);
                                            }
                                            $link .= '</ol></div></div>';
                                            return $link;
                                        }

                                    }

                                    echo generateBreadcrumb();
                                    ?>
                                   
                                    <?php
                                    $pole = array(
                                        'Značka',
                                    );
                                    $this->table->set_heading($pole);
                                    foreach ($znacka as $row) {
                                        $pole = array(
                                            anchor('znacky/' . $row->id, $row->nazev)
                                        );
                                        $this->table->add_row($pole);
                                    }

                                    $template = array(
                                        'table_open' => '<table class="table col-xs-3">',
                                        'thead_open' => '<thead>',
                                        'thead_close' => '</thead>',
                                        'heading_row_start' => '<tr>',
                                        'heading_row_end' => '</tr>',
                                        'heading_cell_start' => '<th>',
                                        'heading_cell_end' => '</th>',
                                        'tbody_open' => '<tbody>',
                                        'tbody_close' => '</tbody>',
                                        'row_start' => '<tr>',
                                        'row_end' => '</tr>',
                                        'cell_start' => '<td>',
                                        'cell_end' => '</td>',
                                        'row_alt_start' => '<tr>',
                                        'row_alt_end' => '</tr>',
                                        'cell_alt_start' => '<td>',
                                        'cell_alt_end' => '</td>',
                                        'table_close' => '</table>'
                                    );

                                    $this->table->set_template($template);
                                    echo $this->table->generate();
                                    ?>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>