<?php
class ObjectClass {
    //put your code here
    
    var $status;
    var $value;
    var $message;
    
    function __construct() {
        
    }
    
    function setParams($status, $value, $message) {
        $this->message = $message;
        $this->status = $status;
        $this->value = $value;
       
        
        
        
        
    }
    
   
}