<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Model extends CI_Model{
    public function __construct() {
        parent::__construct();
    }
  public function pridatModel($nazev, $pic, $karoserie, $barva, $znacka)
    {
     $data = array(
        'nazev'=>$nazev,
        'pic'=>$pic,
        'karoserie'=>$karoserie,
        'barva'=>$barva,
        'znacka_idZnacka'=>$znacka
        
    );
        $this->db->insert('model', $data);   
    }
    public function getZnacka(){
        $this->db->select('idZnacka, nazevZnacky');
        $this->db->from('znacka');
        
        $data = $this->db->get()->result();
        return $data;
    }

}