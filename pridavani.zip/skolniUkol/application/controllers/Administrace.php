<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Administrace extends CI_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->model('Model');
        $this->layout->setLayout('layout/layout_main');
    }
    public function pridatModel() {
        $data["title"] = "Přidat model";
        $data['main'] = 'pridatModel';
        $data['znacka'] = $this->Model->getZnacka();
        var_dump($data);
        $this->layout->generate($data);
    }

    public function pridejModel() {
        $data["title"] = "Přidej model";
        $data['main'] = 'uspesne';
        $data['nazev'] = $this->input->post('nazev');
        $data['pic'] = $this->input->post('pic');
        $data['karoserie'] = $this->input->post('karoserie');
        $data['barva'] = $this->input->post('barva');
        $data['znacka_idZnacka'] = $this->input->post('znacka_idZnacka');
        $data['model'] = $this->Model->pridatModel($data['nazev'], $data['pic'], $data['karoserie'], $data['barva'], $data['znacka_idZnacka']);

        var_dump($data);

        $this->layout->generate($data);
    }

}