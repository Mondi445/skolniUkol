<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Administrace extends CI_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->model('Model');
        $this->layout->setLayout('layout/layout_main');
        $this->load->library('ion_auth');
        $this->load->library('validation_pomocne');
        $this->load->library('objectclass');
    }
    public function pridatModel() {
        $data["title"] = "Přidat model";
        $data['main'] = 'pridatModel';
        $data['znacka'] = $this->Model->getZnacka();
        var_dump($data);
        $this->layout->generate($data);
    }

    public function pridejModel() {
        $data["title"] = "Přidej model";
        $data['main'] = 'uspesne';
        $data['nazev'] = $this->input->post('nazev');
        $data['pic'] = $this->input->post('pic');
        $data['karoserie'] = $this->input->post('karoserie');
        $data['barva'] = $this->input->post('barva');
        $data['znacka_idZnacka'] = $this->input->post('znacka_idZnacka');
        $data['model'] = $this->Model->pridatModel($data['nazev'], $data['pic'], $data['karoserie'], $data['barva'], $data['znacka_idZnacka']);

        var_dump($data);

        $this->layout->generate($data);
    }
    
    public function znacky(){
        $data['title'] = 'Značky';
        $data['main'] = 'znacky';
        $data['znacka'] = $this->Model->getZnacky();
        $this->layout->generate($data);
    }
    
    public function modely($id){
        $data['title'] = 'Modely';
        $data['main'] = 'modely';
        $data['model'] = $this->Model->getModely($id);
        $this->layout->generate($data);
    }
    
    
    //-----------------<PŘIHLÁŠENÍ>-----------------------------------------------
    
    public function login() {

        $data["title"] = "Přihlášení";
        $data["main"] = "prihlaseni";
        $data["message"] = $this->session->flashdata('message');
        $this->layout->generate($data);
    }
    
    public function loginFinish() {

        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $return = $this->ion_auth->login($username, $password);

        if ($return) {
            redirect('Prihlasen/dashboard');
        } else {
            $this->session->set_flashdata('message', 'Nesprávné uživatelské jméno nebo heslo');
            redirect('Administrace/login');
        }
    }
    
    //-------------------------<REGISTRACE>--------------------------------------------
    
    public function register() {
        $password_min = $this->config->item('min_password_length', 'ion_auth');
        $password_max = $this->config->item('max_password_length', 'ion_auth');
        $omezeni = array($password_min, $password_max);
        $inputs = array('name', 'surname', 'email', 'username', 'password', 'confirm');
        
        if(!isset($this->session->data)) {
            $data = $this->validation_pomocne->createFreeArray($inputs);
            $this->session->set_flashdata('data', $data);
        }
        
        $data["omezeni"] = $omezeni;
        $data["title"] = "Registrace";
        $data["main"] = "registrace";
        $this->layout->generate($data);
    }
    
    function registerFinish() {
        //načtení konfiguračních proměnných
        $tables = $this->config->item('tables', 'ion_auth');
        $password_min = $this->config->item('min_password_length', 'ion_auth');
        $password_max = $this->config->item('max_password_length', 'ion_auth');

        //pole z formuláře
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $name = $this->input->post('name');
        $surname = $this->input->post('surname');
        $email = $this->input->post('email');
        $confirm = $this->input->post('confirm');


        //podmínky polí
        $this->form_validation->set_rules('name', 'jméno', 'required');
        $this->form_validation->set_rules('surname', 'příjmení', 'required');
        $this->form_validation->set_rules('email', 'email', 'required|valid_email');
        $this->form_validation->set_rules('username', 'uživatelské jméno', 'required|is_unique[' . $tables['users'] . '.username]');
        $this->form_validation->set_rules('password', 'heslo', 'required|min_length[' . $password_min . ']|max_length[' . $password_max . ']|matches[confirm]');
        $this->form_validation->set_rules('confirm', 'potvrzení hesla', 'required');

        $return = $this->form_validation->run();
        if ($return) {
            $additional_data = array(
                'first_name' => $name,
                'last_name' => $surname
            );
            $this->ion_auth->register($username, $password, $email, $additional_data);
            $this->session->set_flashdata('message', 'Účet byl vytvořen, můžeš se přihlásit');
            redirect('prihlaseni');
        } else {
            
            $inputs = array('name', 'surname', 'email', 'username', 'password', 'confirm');
            $values = array($name, $surname, $email, $username, '', '');
            $data = $this->validation_pomocne->createData($inputs, $this->form_validation->error_array(), $values);
            
            $this->session->set_flashdata('data', $data);
            
            redirect('registrace');
        }
    }

}