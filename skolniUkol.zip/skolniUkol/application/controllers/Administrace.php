<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Administrace extends Admin_controller{
    public function __construct() {
        parent::__construct();
        $this->load->model('Model');
        $this->layout->setLayout('layout/layout_main');
        $this->load->library('ion_auth');
        $this->load->library('validation_pomocne');
        $this->load->library('objectclass');
    }
    public function odhlasit() {
        $this->ion_auth->logout();
        redirect(base_url('prihlaseni'));
    }
    
    public function editace(){
        $data['title'] = 'Editace';
        $data['main'] = 'editace';
        $data['modely'] = $this->Model->vypisModely();
        $data['znacky'] = $this->Model->getZnacka();
        $this->layout->generate($data);
    }
    
    public function editovatModel($id){
        $data['title'] = 'Editovaný model';
        $data['main'] = 'editovatModel';
        $data['znacka'] = $this->Model->getZnacky();
        $data['modely'] = $this->Model->getEditovanyModel($id);
 
        $this->layout->generate($data);
    }
    
    public function smazatModel($id){
        $data['title'] = 'Smazat model';
        $data['main'] = 'smazatModel';
        $data['znacka'] = $this->Model->getZnacky();
        $data['modely'] = $this->Model->getEditovanyModel($id);
 
        $this->layout->generate($data);
    }
    
    public function smazModel() {

        $data['idModel'] = $this->input->post('idModel');
        $data['smazModel'] = $this->Model->smazModel($data['idModel']);
 
        redirect(base_url('/editace'));

        $this->layout->generate($data);
    }
    
    public function smazatZnacku($id){
        $data['title'] = 'Smazat značku';
        $data['main'] = 'smazatZnacku';
        $data['znacka'] = $this->Model->getEditovanaZnacka($id);

        $this->layout->generate($data);
    }
    
    public function smazZnacku() {

        $data['idZnacka'] = $this->input->post('idZnacka');
        $data['smazatZnacku'] = $this->Model->smazZnacku($data['idZnacka']);
        redirect(base_url('/editace'));

        $this->layout->generate($data);
    }
    
    public function editujModel() {

        $data['idModel'] = $this->input->post('idModel');
        $data['nazev'] = $this->input->post('nazev');
        $data['pic'] = $this->input->post('pic');
        $data['karoserie'] = $this->input->post('karoserie');
        $data['barva'] = $this->input->post('barva');
        $data['znacka_idZnacka'] = $this->input->post('znacka_idZnacka');
        $data['editovatModel'] = $this->Model->editujModel($data['idModel'], $data['nazev'], $data['pic'], $data['karoserie'], $data['barva'], $data['znacka_idZnacka']);
 
        redirect(base_url('editovatModel/' . $data['idModel']));

        $this->layout->generate($data);
    }
    
    
    public function editovatZnacku($id){
        $data['title'] = 'Editovaná značka';
        $data['main'] = 'editovatZnacku';
        $data['znacka'] = $this->Model->getEditovanaZnacka($id);

        $this->layout->generate($data);
    }
    
    public function editujZnacku() {

        $data['idZnacka'] = $this->input->post('idZnacka');
        $data['nazevZnacky'] = $this->input->post('nazevZnacky');
        $data['editovatZnacku'] = $this->Model->editujZnacku($data['idZnacka'], $data['nazevZnacky']);
        redirect(base_url('editovatZnacku/' . $data['idZnacka']));

        $this->layout->generate($data);
    }

    public function pridejModel() {
        $data['nazev'] = $this->input->post('nazev');
        $data['pic'] = $this->input->post('pic');
        $data['karoserie'] = $this->input->post('karoserie');
        $data['barva'] = $this->input->post('barva');
        $data['znacka_idZnacka'] = $this->input->post('znacka_idZnacka');
        $data['model'] = $this->Model->pridatModel($data['nazev'], $data['pic'], $data['karoserie'], $data['barva'], $data['znacka_idZnacka']);
        redirect(base_url('/editace'));
        $this->layout->generate($data);
    }
    
     public function pridejZnacku() {
        $data['nazevZnacky'] = $this->input->post('nazevZnacky');
        $data['znacka'] = $this->Model->pridatZnacku($data['nazevZnacky']);
        redirect(base_url('/editace'));
        $this->layout->generate($data);
    }
    
   
    
    
    //-----------------<PŘIHLÁŠENÍ>-----------------------------------------------
    
    
    
    //-------------------------<REGISTRACE>--------------------------------------------
    
    public function register() {
        $password_min = $this->config->item('min_password_length', 'ion_auth');
        $password_max = $this->config->item('max_password_length', 'ion_auth');
        $omezeni = array($password_min, $password_max);
        $inputs = array('name', 'surname', 'email', 'username', 'password', 'confirm');
        
        if(!isset($this->session->data)) {
            $data = $this->validation_pomocne->createFreeArray($inputs);
            $this->session->set_flashdata('data', $data);
        }
        
        $data["omezeni"] = $omezeni;
        $data["title"] = "Registrace";
        $data["main"] = "registrace";
        $this->layout->generate($data);
    }
    
    function registerFinish() {
        //načtení konfiguračních proměnných
        $tables = $this->config->item('tables', 'ion_auth');
        $password_min = $this->config->item('min_password_length', 'ion_auth');
        $password_max = $this->config->item('max_password_length', 'ion_auth');

        //pole z formuláře
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $name = $this->input->post('name');
        $surname = $this->input->post('surname');
        $email = $this->input->post('email');
        $confirm = $this->input->post('confirm');


        //podmínky polí
        $this->form_validation->set_rules('name', 'jméno', 'required');
        $this->form_validation->set_rules('surname', 'příjmení', 'required');
        $this->form_validation->set_rules('email', 'email', 'required|valid_email');
        $this->form_validation->set_rules('username', 'uživatelské jméno', 'required|is_unique[' . $tables['users'] . '.username]');
        $this->form_validation->set_rules('password', 'heslo', 'required|min_length[' . $password_min . ']|max_length[' . $password_max . ']|matches[confirm]');
        $this->form_validation->set_rules('confirm', 'potvrzení hesla', 'required');

        $return = $this->form_validation->run();
        if ($return) {
            $additional_data = array(
                'first_name' => $name,
                'last_name' => $surname
            );
            $this->ion_auth->register($username, $password, $email, $additional_data);
            $this->session->set_flashdata('message', 'Účet byl vytvořen, můžeš se přihlásit');
            redirect('prihlaseni');
        } else {
            
            $inputs = array('name', 'surname', 'email', 'username', 'password', 'confirm');
            $values = array($name, $surname, $email, $username, '', '');
            $data = $this->validation_pomocne->createData($inputs, $this->form_validation->error_array(), $values);
            
            $this->session->set_flashdata('data', $data);
            
            redirect('registrace');
        }
    }

}