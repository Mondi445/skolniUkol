<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Administrace extends Admin_controller{
    public function __construct() {
        parent::__construct();
        $this->load->model('Model');
        $this->layout->setLayout('layout/layout_main');
        $this->load->library('ion_auth');
        $this->load->library('validation_pomocne');

    }
    public function odhlasit() {
        $this->ion_auth->logout();
        redirect(base_url('prihlaseni'));
    }
    
    public function editace(){
        $data['title'] = 'Editace';
        $data['main'] = 'editace';
        $data['modely'] = $this->Model->vypisModely();
        $data['znacky'] = $this->Model->getZnacka();
        $this->layout->generate($data);
    }
    
    public function editovatModel($id){
        $data['title'] = 'Editovaný model';
        $data['main'] = 'editovatModel';
        $data['znacka'] = $this->Model->getZnacky();
        $data['modely'] = $this->Model->getEditovanyModel($id);
 
        $this->layout->generate($data);
    }
    
    public function smazatModel($id){
        $data['title'] = 'Smazat model';
        $data['main'] = 'smazatModel';
        $data['znacka'] = $this->Model->getZnacky();
        $data['modely'] = $this->Model->getEditovanyModel($id);
 
        $this->layout->generate($data);
    }
    
    public function smazModel() {

        $data['idModel'] = $this->input->post('idModel');
        $data['smazModel'] = $this->Model->smazModel($data['idModel']);
 
        redirect(base_url('/editace'));

        $this->layout->generate($data);
    }
    
    public function smazatZnacku($id){
        $data['title'] = 'Smazat značku';
        $data['main'] = 'smazatZnacku';
        $data['znacka'] = $this->Model->getEditovanaZnacka($id);

        $this->layout->generate($data);
    }
    
    public function smazZnacku() {

        $data['idZnacka'] = $this->input->post('idZnacka');
        $data['smazatZnacku'] = $this->Model->smazZnacku($data['idZnacka']);
        redirect(base_url('/editace'));

        $this->layout->generate($data);
    }
    
    public function editujModel() {

        $data['idModel'] = $this->input->post('idModel');
        $data['nazev'] = $this->input->post('nazev');
        $data['pic'] = $this->input->post('pic');
        $data['karoserie'] = $this->input->post('karoserie');
        $data['barva'] = $this->input->post('barva');
        $data['znacka_idZnacka'] = $this->input->post('znacka_idZnacka');
        $data['editovatModel'] = $this->Model->editujModel($data['idModel'], $data['nazev'], $data['pic'], $data['karoserie'], $data['barva'], $data['znacka_idZnacka']);
 
        redirect(base_url('editovatModel/' . $data['idModel']));

        $this->layout->generate($data);
    }
    
    
    public function editovatZnacku($id){
        $data['title'] = 'Editovaná značka';
        $data['main'] = 'editovatZnacku';
        $data['znacka'] = $this->Model->getEditovanaZnacka($id);

        $this->layout->generate($data);
    }
    
    public function editujZnacku() {

        $data['idZnacka'] = $this->input->post('idZnacka');
        $data['nazevZnacky'] = $this->input->post('nazevZnacky');
        $data['editovatZnacku'] = $this->Model->editujZnacku($data['idZnacka'], $data['nazevZnacky']);
        redirect(base_url('editovatZnacku/' . $data['idZnacka']));

        $this->layout->generate($data);
    }

    public function pridejModel() {
        $config['upload_path']          = './assets/images/modely/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 100;
        $config['max_width']            = 1024;
        $config['max_height']           = 768;
        $config['file_name'] = $this->upload->data('file_name');
        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $data['nazev'] = $this->input->post('nazev');   
        $data['karoserie'] = $this->input->post('karoserie');
        $data['barva'] = $this->input->post('barva');
        $data['znacka_idZnacka'] = $this->input->post('znacka_idZnacka');
        $this->upload->do_upload('userfile');
        if(!$this->upload->do_upload('userfile')){
            redirect('/editace');
        }else{
        $data['model'] = $this->Model->pridatModel($data['nazev'], $this->upload->data('file_name'), $data['karoserie'], $data['barva'], $data['znacka_idZnacka']);
        redirect(base_url('/editace'));
        $this->layout->generate($data['model']);
        }
        
    }
     public function pridejZnacku() {
        $data['nazevZnacky'] = $this->input->post('nazevZnacky');
        $data['znacka'] = $this->Model->pridatZnacku($data['nazevZnacky']);
        redirect(base_url('/editace'));
        $this->layout->generate($data);
    }
    
   
    
    
    //-----------------<PŘIHLÁŠENÍ>-----------------------------------------------
    
    
    
    //-------------------------<REGISTRACE>--------------------------------------------
    
    

}