<?php

class Neprihlasen extends CI_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->model('Model');
        $this->layout->setLayout('layout/layout_main');
        $this->load->library('ion_auth');
       
    }
    
    public function login() {

        $data["title"] = "Přihlášení";
        $data["main"] = "prihlaseni";
        $data["message"] = $this->session->flashdata('message');
        $this->layout->generate($data);
    }
    
    public function loginFinish() {

        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $return = $this->ion_auth->login($username, $password);

        if ($return) {
            redirect('znacky');
        } else {
            $this->session->set_flashdata('message', 'Nesprávné uživatelské jméno nebo heslo');
            redirect('prihlaseni');
        }
    }
     public function znacky(){
        $data['title'] = 'Značky';
        $data['main'] = 'znacky';
        
        $data['znacka'] = $this->Model->getZnacky();
        $data['nazevZnacka'] = $this->Model->getNazevZnacky();
        $this->layout->generate($data);
       
    }
   
    
    public function modely($id){
        $data['title'] = 'Modely';
        $data['main'] = 'modely';
        $data['model'] = $this->Model->getModely($id);
        $data['nazevZnacka'] = $this->Model->getNazevZnacky();
        $this->layout->generate($data);
    }
}