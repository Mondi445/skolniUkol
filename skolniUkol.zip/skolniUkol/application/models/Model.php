<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Model extends CI_Model{
    public function __construct() {
        parent::__construct();
    }
  public function pridatModel($nazev, $pic, $karoserie, $barva, $znacka)
    {
     $data = array(
        'nazev'=>$nazev,
        'pic'=>$pic,
        'karoserie'=>$karoserie,
        'barva'=>$barva,
        'znacka_idZnacka'=>$znacka
        
    );
        $this->db->insert('model', $data);   
    }
    public function getZnacka(){
        $this->db->select('idZnacka, nazevZnacky');
        $this->db->from('znacka');
        
        $data = $this->db->get()->result();
        return $data;
    }
    
    public function getZnacky(){
        $this->db->select('idZnacka as id, nazevZnacky as nazev');
        $this->db->from('znacka');
        
        $data = $this->db->get()->result();
        return $data;
    }
    public function getModely($id){
        $this->db->select('idModel, nazev, pic, karoserie, barva, znacka_idZnacka as idZnacka, znacka.idZnacka, znacka.nazevZnacky as NZnacky');
        $this->db->from('model');
        $this->db->join('znacka', ' model.znacka_idZnacka = znacka.idZnacka', 'inner');
        $this->db->where('znacka.idZnacka',$id);
        
        $data = $this->db->get()->result();
        return $data;
    }

}