<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Model extends CI_Model{
    public function __construct() {
        parent::__construct();
    }
  
    public function getNazevZnacky(){
        $this->db->select('idZnacka, nazevZnacky');
        $this->db->from('znacka');
        
        $data = $this->db->get()->result();
        return $data;
    }
    
    public function pridatModel($nazev, $pic, $karoserie, $barva, $znacka)
    {
     $data = array(
        'nazev'=>$nazev,
        'pic'=>$pic,
        'karoserie'=>$karoserie,
        'barva'=>$barva,
        'znacka_idZnacka'=>$znacka
        
    );
        $this->db->insert('model', $data);   
    }
    
    public function pridatZnacku($nazev)
    {
     $data = array(
        'nazevZnacky'=>$nazev,
    );
        $this->db->insert('znacka', $data);   
    }
    public function getZnacka(){
        $this->db->select('idZnacka, nazevZnacky');
        $this->db->from('znacka');
        
        $data = $this->db->get()->result();
        return $data;
    }
    
    public function getZnacky(  ){
        $this->db->select('idZnacka as id, nazevZnacky as nazev');
        $this->db->from('znacka');
        $this->db->order_by('nazev');
        $data = $this->db->get()->result();
        return $data;
    }
    
    public function getEditovanaZnacka($id){
        $this->db->select('idZnacka, nazevZnacky');
        $this->db->from('znacka');
        $this->db->where('idZnacka',$id);
        $data = $this->db->get()->result();
        return $data;
    }
    
    public function editujZnacku($id, $nazev) {
        $data = array(
            'nazevZnacky' => $nazev,
        );
        
        $this->db->where('idZnacka', $id);
        $this->db->update('znacka', $data);
    }
    public function getModely($id){
        $this->db->select('idModel, nazev, pic, karoserie, barva, znacka_idZnacka as idZnacka, znacka.idZnacka, znacka.nazevZnacky as NZnacky');
        $this->db->from('model');
        $this->db->join('znacka', ' model.znacka_idZnacka = znacka.idZnacka', 'inner');
        $this->db->where('znacka.idZnacka',$id);
        
        $data = $this->db->get()->result();
        return $data;
    }
    public function vypisModely(){
        $this->db->select('idModel, nazev, pic, karoserie, barva, znacka_idZnacka as idZnacka, znacka.idZnacka, znacka.nazevZnacky as NZnacky');
        $this->db->from('model');
        $this->db->join('znacka', ' model.znacka_idZnacka = znacka.idZnacka', 'inner');
        
        $data = $this->db->get()->result();
        return $data;
    }
    public function getEditovanyModel($id){
        $this->db->select('idModel, nazev, pic, karoserie, barva, znacka_idZnacka as idZnacka, znacka.idZnacka, znacka.nazevZnacky as NZnacky');
        $this->db->from('model');
        $this->db->join('znacka', ' model.znacka_idZnacka = znacka.idZnacka', 'inner');
        $this->db->where('idModel',$id);
        
        $data = $this->db->get()->result();
        return $data;
    }
    public function editujModel($id, $nazev, $pic, $karoserie, $barva, $idZnacky) {
        $data = array(
            'nazev' => $nazev,
            'pic' => $pic,
            'karoserie' => $karoserie,
            'barva' => $barva,
            'znacka_idZnacka' => $idZnacky
        );
        
        $this->db->where('idModel', $id);
        $this->db->update('model', $data);
    }
    public function smazModel($id) {
        $this->db->where('idModel', $id);
        $this->db->delete('model');
    }
    
    public function smazZnacku($id) {
        $this->db->where('idZnacka', $id);
        $this->db->delete('znacka');
    }

}