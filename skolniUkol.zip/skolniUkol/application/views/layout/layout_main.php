<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
        <title><?php echo $title ?></title>
        <link href=<?php echo base_url('assets/bootstrap/css/bootstrap.min.css'); ?> rel="stylesheet" type="text/css"/>
        <link href=<?php echo base_url('assets/bootstrap/css/bootstrap-theme.min.css'); ?> rel="stylesheet" type="text/css"/>
        <link href=<?php echo base_url('assets/css/style.css'); ?> rel="stylesheet" type="text/css"/>
        <script src=<?php echo base_url('assets/jquery/jquery-3.2.1.min.js'); ?></script>
        <script src=<?php echo base_url('assets/bootstrap/js/bootstrap.min.js'); ?></script>
        <link href=<?php echo base_url('assets/fontawesome/css/font-awesome.css'); ?> rel="stylesheet" type="text/css"/>
        <link href=<?php echo base_url('assets/fontawesome/css/font-awesome.min.css'); ?> rel="stylesheet" type="text/css"/>
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <link href=<?php echo base_url('assets/styles/style.css'); ?> rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <nav class="menu nav navbar-brand">
            <div class="menu-container">
                <ul class="menu-list">
                    <li class="menu-item">
                        <a class="menu-item" href="<?php echo base_url('/znacky'); ?>">Domů</a>
                    </li>
                    <li class="menu-item">
                        <?php if ($this->ion_auth->logged_in()) { ?>
                            <a class="menu-item" href="<?php echo base_url('/editace'); ?>">Editace</a>
                        <?php } ?>
                    </li>
                    <li class="menu-item">
                        <?php if (!$this->ion_auth->logged_in()) { ?>
                            <a class="menu-item" href="<?php echo base_url('/prihlaseni'); ?>">Příhlášení</a> 
                            <?php
                        }
                        if ($this->ion_auth->is_admin()) {
                            ?>
                            <a class="menu-item" href="<?php echo base_url('/registrace'); ?>">Registrace</a>
                        <?php } ?>
                    </li>
                    <li class="menu-item">
                        <?php if ($this->ion_auth->logged_in()) { ?>
                            <a class="menu-item" href="<?php echo base_url('/Administrace/odhlasit'); ?>">Odhlásit se</a>
                        <?php } ?>
                    </li>
                    <li class="menu-item">
                        <?php if (!$this->ion_auth->logged_in()) { ?>
                        <p class="barvicka">Nepřihlášený uživatel</p>
                        <?php } ?>
                        <?php if($this->ion_auth->logged_in()){?> 
                            <!--<p class="barvicka"><?php echo $this->user->username; ?></p>-->
                        <?php }?>
                    </li>
                </ul>
            </div>
            <a class="menu-toggle">
                <span class="menu-hamburger"></span>
            </a>
        </nav>
        <script>
            $('.menu-toggle').on('click', function () {
                $('.menu').toggleClass('active');
            });
        </script>
        <style>
            html,body{
                margin: 0;
                padding: 0;
                height: 100%;

            }
            body{

            }
            .menu{
                height: 100%;
                overflow:hidden;
            }
            .menu-container{
                will-change: transform,height;
                width: 300px;
                height: 500px;
                background-color: black;
                padding-left: 100px;
                box-sizing: border-box;
                transform: translate3d(-330px, -210px, 0px) rotate(45deg);
                margin: 0;
                position: relative;
                transition: all 0.3s ease-in-out;
                font-family: tahoma;
            }
            nav.active .menu-container{
                height: 200%;
                transform: translate3d(-100px, 0px, 0px) rotate(0deg);
            }
            .menu-list{
                margin: 0;
                padding: 50px 20px 20px 50px;
                list-style: none;
            }
            .menu-item{
                padding: .5rem 0;
            }
            menu-link{
                color:white;
                text-decoration: none;
                text-transform: uppercase;
                font-size: .9rem;
                font-weight: bold;
                opacity: 0;
                transition: opacity .3s;
            }
            nav.active .menu-link{
                opacity: 1;
                transition-delay: .3s;
            }
            .menu-toggle{
                display: block;
                position:absolute;
                height: 15px;
                width: 20px;
                top: 12px;
                left: 12px;
                background: transparent;
                cursor: pointer;
            }
            .menu-hamburger, .menu-hamburger:before, .menu-hamburger:after{
                background-color: white;
                height: 3px;
                width: 20px;
                display: block;
                transition: all .3s;
            }
            .menu-hamburger{
                position: relative;
                top: 5px;
                left: 0px;
            }
            .menu-hamburger:before{
                content: "";
                position: absolute;
                top: -6px;
            }
            .menu-hamburger:after{
                content: "";
                position: absolute;
                bottom: -6px;
            }
            .menu.active .menu-hamburger:before{
                transform: rotate(-45deg);
                top: 0px;
            }
            .menu.active .menu-hamburger:after{
                transform: rotate(75deg);
                bottom: 0px;
            }
            .menu.active .menu-hamburger{
                background: transparent;
            }
        </style>



        <article>
            <div class="container">


                <?php
                echo $content;
                ?>
            </div>



        </article>
        <script src='<?php echo base_url('assets/jquery/jquery.js'); ?>' type="text/javascript"></script>
        <script src='<?php echo base_url('assets/bootstrap/js/bootstrap.min.js'); ?>' type="text/javascript"></script>
    </body>
</html>


