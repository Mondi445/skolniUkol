

<div class="navbar-header">
                    <?php
                    if (!$this->ion_auth->logged_in()) { ?>
                    <a class="navbar-brand" href="<?php echo base_url('/prihlaseni'); ?>">Příhlášení</a> 
                    <?php }
                     if ($this->ion_auth->logged_in()) { ?>
                    <a class="navbar-brand" href="<?php echo base_url('/registrace'); ?>">Registrace</a>
                    <a class="navbar-brand" href="<?php echo base_url('/Administrace/odhlasit'); ?> ">Odhlásit se</a>
                     <?php }?>
                    
                </div>
