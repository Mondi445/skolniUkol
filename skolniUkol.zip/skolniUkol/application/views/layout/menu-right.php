
<?php
echo anchor('prihlaseni', 'Přihlášení');
echo anchor('registrace', 'Registrace');

