<?php
echo heading("Editovat model", 1);
$atributy = array(
    'class' => 'form-horizontal'
    );
$hidden = array(
    'idModel' => $modely[0]->idModel,
);
echo form_open('Administrace/editujModel', $atributy, $hidden);
//tady začíná první řádek
echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Název: ','nazev', $atributy);

echo "<div class='col-sm-6'>";

$atributy = array(
  'class' => 'form-control',
    'id' => 'nazev',
    'value' => $modely[0]->nazev,
    'name' => 'nazev'
);    
echo form_input($atributy);
echo '</div></div>';
// tady konci prvni radek







//tady začíná první řádek
echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Obrázek:','pic', $atributy);

echo "<div class='col-sm-6'>";

$atributy = array(
  'class' => 'form-control',
    'id' => 'pic',
    'value' => $modely[0]->pic,
    'name' => 'pic'
);    
echo form_input($atributy);
echo '</div></div>';


echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Karoserie','karoserie', $atributy);

echo "<div class='col-sm-6'>";

$atributy = array(
  'class' => 'form-control',
    'id' => 'karoserie',
    'value' => $modely[0]->karoserie,
    'name' => 'karoserie'
);    
echo form_input($atributy);
echo '</div></div>';
// tady konci prvni radek


echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Barva','barva', $atributy);

echo "<div class='col-sm-6'>";

$atributy = array(
  'class' => 'form-control',
    'id' => 'barva',
    'value' => $modely[0]->barva,
    'name' => 'barva'
);    
echo form_input($atributy);
echo '</div></div>';
// tady konci prvni radek


echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Značka','', $atributy);

echo "<div class='col-sm-6'>";
$options[$modely[0]->idZnacka] = $znacka[0]->nazev;
foreach($znacka as $row)
    {    
        $options[$row->id]= $row->nazev;      
    }
    $settings = array
(
    'class' => 'form-control',   
);
    
echo form_dropdown('znacka_idZnacka', $options, '', $settings);
echo '</div></div>';

$data = array(
    'name' => 'Editovat',
    'type' => 'submit',
    'content' => 'Editovat model',
    'class' => 'btn btn-danger'
);
echo "<div class='form-group'>";
echo "<div class='col-sm-offset-2 col-sm-4'>";
echo form_button($data);
echo "</div></div>"; 
echo form_close();

echo "<a class=anavratove href=" .base_url('/editace') . ">Zpět k modelům</a>";