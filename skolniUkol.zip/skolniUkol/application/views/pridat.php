<?php
echo heading("Přidat model", 1);
$atributy = array(
    'class' => 'form-horizontal'
    );
echo form_open('Administrace/pridejModel', $atributy);

echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Název','nazev', $atributy);

echo "<div class='col-sm-6'>";

$atributy = array(
  'class' => 'form-control',
    'id' => 'nazev',
    'placeholder' => 'vložte název',
    'name' => 'nazev'
);    
echo form_input($atributy);
echo '</div></div>';

echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Název obrázku','pic', $atributy);

echo "<div class='col-sm-6'>";

$atributy = array(
  'class' => 'form-control',
    'id' => 'pic',
    'placeholder' => 'vložte název obrázku',
    'name' => 'pic'
);    
echo form_input($atributy);
echo '</div></div>';


echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Karoserie','karoserie', $atributy);

echo "<div class='col-sm-6'>";

$atributy = array(
  'class' => 'form-control',
    'id' => 'karoserie',
    'placeholder' => 'vložte karoserii',
    'name' => 'karoserie'
);    
echo form_input($atributy);
echo '</div></div>';




echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Barva','barva', $atributy);

echo "<div class='col-sm-6'>";

$atributy = array(
  'class' => 'form-control',
    'id' => 'barva',
    'placeholder' => 'vložte barvu',
    'name' => 'barva'
);    
echo form_input($atributy);
echo '</div></div>';


echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Značka auta','', $atributy);

echo "<div class='col-sm-6'>";

foreach($znacka as $row)
    {
        $options[$row->idZnacka] = $row->nazevZnacky;
    }
    $settings = array
(
    'class' => 'form-control'
);
echo form_dropdown('znacka_idZnacka', $options, '', $settings);
echo '</div></div>';




$data = array(
    'name' => 'Přidat',
    'type' => 'submit',
    'content' => 'Přidat model',
    'class' => 'btn btn-danger'
);
echo "<div class='form-group'>";
echo "<div class='col-sm-offset-2 col-sm-4'>";
echo form_button($data);
echo "</div></div>"; 
echo form_close();









echo heading("Přidat značku", 1);
$atributy = array(
    'class' => 'form-horizontal'
    );
echo form_open('Administrace/pridejZnacku', $atributy);

echo "<div class='form-group'>";
$atributy = array
(
    'class' => 'control-label col-sm-2'
);
echo form_label('Název značky:','nazevZnacky', $atributy);

echo "<div class='col-sm-6'>";

$atributy = array(
  'class' => 'form-control',
    'id' => 'nazevZnacky',
    'placeholder' => 'vložte název',
    'name' => 'nazevZnacky'
);    
echo form_input($atributy);
echo '</div></div>';




$data = array(
    'name' => 'Přidat',
    'type' => 'submit',
    'content' => 'Přidat značku',
    'class' => 'btn btn-danger'
);
echo "<div class='form-group'>";
echo "<div class='col-sm-offset-2 col-sm-4'>";
echo form_button($data);
echo "</div></div>"; 
echo form_close();