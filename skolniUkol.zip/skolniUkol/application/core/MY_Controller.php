<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Admin_controller extends CI_Controller {

    function __construct() {
        parent::__construct();

        if (!$this->ion_auth->is_admin()){
            redirect('prihlaseni');
        } else {
           $this->load->model('MAdministrace');
            $this->layout->setLayout ('/layout/layout_administrace');
            $this->load->library('Validation_pomocne');
        }
    }

}
class MY_Controller_Editor extends CI_Controller {
    function __construct() {
        parent::__construct();
        if ($this->ion_auth->logged_in()){
            $this->load->model('MAdministrace');
            $this->layout->setLayout ('/layout/layout_administrace');
            $this->load->library('Validation_pomocne');
            
        }else{
            redirect('prihlaseni');
        }
       
        }
        
    }
