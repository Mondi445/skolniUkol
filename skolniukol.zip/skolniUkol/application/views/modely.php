<div class="container odsazeni">
    <div class="row blog">
        <div class="col-md-12">
            <div id="blogCarousel" class="carousel slide" data-ride="carousel">
                <div class="main-login2 main-center2">


                    <!-- Carousel items -->
                        <h1 class="title text-center" >
                            Modely
                        </h1>

                        <div class="carousel-item active">
                            <div class="row">
                                <h1>
                                    Modely
                                </h1>
                                <?php
                                if (!function_exists('generateBreadcrumb')) {

                                    function generateBreadcrumb() {
                                        $ci = &get_instance();
                                        $i = 1;
                                        $uri = $ci->uri->segment($i);
                                        $link = '<div class="pageheader"><div class="breadcrumb-wrapper"><ol class="breadcrumb">';
                                        while ($uri != '') {
                                            $prep_link = '';
                                            for ($j = 1; $j <= $i; $j++) {
                                                $prep_link .= $ci->uri->segment($j) . '/';
                                            }
                                            if ($ci->uri->segment($i + 1) == '') {
                                                $link .= '<li class="active"><a href="' . site_url($prep_link) . '">';
                                                $link .= $ci->uri->segment($i) . '</a></li>';
                                            } else {
                                                $link .= '<li><a href="' . site_url($prep_link) . '">';
                                                $link .= $ci->uri->segment($i) . '</a><span class="divider"></span></li>';
                                            }
                                            $i++;
                                            $uri = $ci->uri->segment($i);
                                        }
                                        $link .= '</ol></div></div>';
                                        return $link;
                                    }

                                }

                                echo generateBreadcrumb();
                                ?>

                                <?php
                                $pole = array(
                                    'Značka',
                                    'Model',
                                    'Barva',
                                    'Karoserie',
                                    'Foto'
                                );
                                $this->table->set_heading($pole);
                                foreach ($model as $row) {
                                    $image_properties = array(
                                        'src' => 'assets/images/modely/' . $row->pic,
                                        'class' => 'post_images',
                                        'height' => '75');

                                    $pole = array(
                                        $row->NZnacky,
                                        $row->nazev,
                                        $row->barva,
                                        $row->karoserie,
                                        img($image_properties)
                                    );
                                    $this->table->add_row($pole);
                                }

                                $template = array(
                                    'table_open' => '<table class="table col-xs-3">',
                                    'thead_open' => '<thead>',
                                    'thead_close' => '</thead>',
                                    'heading_row_start' => '<tr>',
                                    'heading_row_end' => '</tr>',
                                    'heading_cell_start' => '<th>',
                                    'heading_cell_end' => '</th>',
                                    'tbody_open' => '<tbody>',
                                    'tbody_close' => '</tbody>',
                                    'row_start' => '<tr>',
                                    'row_end' => '</tr>',
                                    'cell_start' => '<td>',
                                    'cell_end' => '</td>',
                                    'row_alt_start' => '<tr>',
                                    'row_alt_end' => '</tr>',
                                    'cell_alt_start' => '<td>',
                                    'cell_alt_end' => '</td>',
                                    'table_close' => '</table>'
                                );

                                $this->table->set_template($template);
                                echo $this->table->generate();
                                ?>
                            </div>
                        </div>         
                </div>
            </div>
        </div>
    </div>
</div>